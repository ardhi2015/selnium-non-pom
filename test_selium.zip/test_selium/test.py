from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome(executable_path='./chromedriver')
driver.maximize_window()
driver.get('https://www.demoblaze.com/')
driver.find_element(By.CSS_SELECTOR, '#login2').click()
time.sleep(5)
driver.find_element(By.CSS_SELECTOR, '#loginusername').send_keys('login')
time.sleep(5)


driver.quit()